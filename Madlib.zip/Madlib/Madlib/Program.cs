﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Madlib
{
    class Program
    {
        static void Main(string[] args)
        {
            //declare variables
            string creature;
            string luminous;
            string ghastly;
            string spectral;
            string countryman;
            string farrier;
            string farmer;
            string dreadful;
            string apparition;
            string hound;
            string story;


            //write out a header 
            Console.WriteLine("_______");
            Console.WriteLine("Madlib!");
            Console.WriteLine("_______");

            //ask player to enter words
            Console.Write("Please enter a noun: ");
            creature = Console.ReadLine();
            Console.Write("\nPlease enter a item: ");
            luminous = Console.ReadLine();
            Console.Write("\nPlease enter a description: ");
            ghastly = Console.ReadLine();
            Console.Write("\nPlease enter a noun: ");
            spectral = Console.ReadLine();
            Console.Write("\nPlease enter an noun: ");
            countryman = Console.ReadLine();
            Console.Write("\nPlease enter a name: ");
            farrier = Console.ReadLine();
            Console.Write("\nPlease enter a place: ");
            farmer = Console.ReadLine();
            Console.Write("\nPlease enter a noun: ");
            dreadful = Console.ReadLine();
            Console.Write("\nPlease enter a noun: ");
            apparition = Console.ReadLine();
            Console.Write("\nPlease enter a action: ");
            hound = Console.ReadLine();

            story = "They all new that the thing in the closet was "
                +creature+". Every time its "+luminous+" touched the sky it looked "
                +ghastly+" the " +creature + " was guarding the lost "+spectral+" of the Legends. All of the "
                +countryman +" feared it, and told the story of "+farrier+" of "+farmer+". That took the "
                +spectral+" and ran leaving only the "+dreadful+" in the city of "+apparition+". Thus the "
                +spectral+" became a legand, wanted by the kings of old, and many greedy men that will "+hound+" for it.";
            Console.Write(story);
            Console.ReadKey();

            Console.Write("\nPress any Key to continue");
            Console.ReadKey();






            //write out finished story


            //keep window open and prompt for exit


        }
    }
}
